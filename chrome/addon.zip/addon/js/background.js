chrome.browserAction.onClicked.addListener(()=>{
    chrome.tabs.create({
        url: "http://www.cursors.anits.edu.in/"
    })
});
